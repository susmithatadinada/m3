package com.cg.custapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.custapp.bean.Customer;
import com.cg.custapp.exception.CustomerException;
import com.cg.custapp.service.CustomerService;

@RestController
public class CustomerController {
	@Autowired
	CustomerService customerService;

	@RequestMapping("/customers")
	public List<Customer> getCustomers() throws CustomerException {
		return customerService.getAllCustomers();

	}

	@RequestMapping("/customers/{id}")
    public Customer getCustomerById(@PathVariable int id) throws CustomerException {
        return customerService.getCustomerById(id);
       
    }
	@RequestMapping("/customers/city")
    public List<Customer> getCustomerByCity(@RequestParam String city) throws CustomerException {
        return customerService.getCustomerByCity(city);
	}

	@RequestMapping(value = "/customers", method = RequestMethod.POST)
	public ResponseEntity<String> addCustomer(@RequestBody Customer customer) throws CustomerException {
		customerService.addCustomer(customer);
		return new ResponseEntity<String>("Customer Added Successfully", HttpStatus.CREATED);
	}

	@RequestMapping(value="/customers/{id}", method=RequestMethod.PUT)
    public ResponseEntity<String> updateCustomer(@PathVariable("id") int id, @RequestBody Customer customer) throws CustomerException {
        customerService.updateCustomer(id,customer);
        return new ResponseEntity<String>("Customer Updated Successfully",HttpStatus.OK);
    }

	@RequestMapping(value = "/customers/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteCustomer(@PathVariable("id") int id) throws CustomerException {
		customerService.deleteCustomer(id);
		return new ResponseEntity<String>("Customer Deleted Successfully", HttpStatus.OK);
	}
	/*@ExceptionHandler({CustomerException.class})
public ResponseEntity<String> handleErrors(Exception e){
	return new ResponseEntity<String>("An Error Occured"+e.getMessage(),HttpStatus.OK);
	
}*/
}