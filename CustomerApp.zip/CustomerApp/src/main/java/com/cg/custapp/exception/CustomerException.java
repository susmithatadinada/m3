package com.cg.custapp.exception;


public class CustomerException extends Exception {
public CustomerException() {
	
}
public CustomerException(String msg) {
	super(msg);
}
}
