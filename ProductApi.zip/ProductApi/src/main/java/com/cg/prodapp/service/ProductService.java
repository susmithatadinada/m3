package com.cg.prodapp.service;

import java.util.List;

import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.prodapp.bean.Product;

public interface ProductService {
	List<Product> getAllProducts();

	Product getProductById(int id);

	void addProduct(Product product);

	void updateProduct(Product product);

	void deleteProduct(int id);

	List<Product> getProductByPrice(double price1, double price2);

	List<Product> getProductBycategory(String cate);

	boolean doValidation(String cate, int quantity);
}
