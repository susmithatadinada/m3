package com.cg.prodapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.prodapp.bean.Product;
import com.cg.prodapp.service.ProductService;


@RestController
public class ProductController {
	@Autowired
	ProductService productService;
	@RequestMapping("/api/products")
public List<Product> getAllProduct(){
	return productService.getAllProducts();
}
	@RequestMapping("/api/products/{id}")
	public Product getAllProduct(@PathVariable int id){
		return productService.getProductById(id);
	}
	@RequestMapping(value = "/api/products/{id}",method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteProduct(@PathVariable int id){
		productService.deleteProduct(id);
		return new ResponseEntity<String>("Product with the id"+id+"deleted",HttpStatus.OK);
	}
	@PostMapping("/api/products")
		public ResponseEntity<String> addProduct(@RequestBody Product product) {
		String cate = product.getCategory();
        int qty = product.getQuantity();
        boolean check = productService.doValidation(cate,qty);
        if(check==false) {
            return new ResponseEntity<String>("Category can be tv, laptop and mobile and quantity must be greater than 0.", HttpStatus.OK);
        }
        else {
           		productService.addProduct(product);
		return new ResponseEntity<String>("Product Successfully added",HttpStatus.OK);}
	}
	@PutMapping("/api/products/{id}")
	public ResponseEntity<String> updateEmployee(@RequestBody Product product) {
		productService.updateProduct(product);
		return new ResponseEntity<String>("Product Successfully updated",HttpStatus.OK);
	}
	@RequestMapping("/api/products/price")
    public List<Product> getProductByPrice(@RequestParam double price1, double price2){
       return productService.getProductByPrice(price1,price2);
}
	@GetMapping("/api/products/category")
    public List<Product> getProductBycategory(@RequestParam("category") String cate) {
       
        return productService.getProductBycategory(cate);
       
    }
	
}