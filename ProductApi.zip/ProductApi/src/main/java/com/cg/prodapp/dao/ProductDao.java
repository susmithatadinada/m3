package com.cg.prodapp.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.prodapp.bean.Product;

@Repository
public interface ProductDao extends JpaRepository<Product, Integer> {

	@Query("from Product where price BETWEEN :p1 AND :p2")
	List<Product> getProductByPrice(@Param("p1") double price1, @Param("p2") double price2);

	@Query("from Product where category=:cate")
	List<Product> getProductByCategory(@Param("cate") String cate);
}
