package com.cg.prodapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.prodapp.bean.Product;
import com.cg.prodapp.dao.ProductDao;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductDao productDao;

	@Override
	public List<Product> getAllProducts() {

		// TODO Auto-generated method stub
		return productDao.findAll();
	}

	@Override
	public Product getProductById(int id) {
		// TODO Auto-generated method stub
		return productDao.findById(id).get();
	}

	@Override
	public void updateProduct(Product product) {
		// TODO Auto-generated method stub

		productDao.save(product);
	}

	@Override
	public void addProduct(Product product) {

		if (product.getQuantity() > 0)
			// TODO Auto-generated method stub
			productDao.save(product);

	}

	@Override
	public void deleteProduct(int id) {
		// TODO Auto-generated method stub
		productDao.deleteById(id);
	}

	@Override
	public List<Product> getProductByPrice(double price1, double price2) {
		return productDao.getProductByPrice(price1, price2);
	}

	@Override
	public List<Product> getProductBycategory(String cate) {
		return productDao.getProductByCategory(cate);
	}

	@Override
	public boolean doValidation(String cate, int quantity) {
		if (cate.equals("Laptop") || cate.equals("Tv") || cate.equals("Mobile") && quantity > 0)
			return true;
		// TODO Auto-generated method stub

		else
			return false;
	}
}
