package com.cg.empapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.empapp.bean.Employee;
import com.cg.empapp.dao.EmployeeDao;
@Service
public class EmployeeServiceImpl implements EmployeeService{
@Autowired
	EmployeeDao employeeDao;
	@Override
	public List<Employee> getAllEmployees() {
		
		// TODO Auto-generated method stub
		return employeeDao.findAll();
	}

	@Override
	public Employee getEmployeeById(int id) {
		// TODO Auto-generated method stub
		return employeeDao.findById(id).get();
	}

	@Override
	public void updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		employeeDao.save(emp);
	}

	@Override
	public void addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		employeeDao.save(emp);
	}

	@Override
	public void deleteEmployee(int id) {
		// TODO Auto-generated method stub
		employeeDao.deleteById(id);
	}

	@Override
    public List<Employee> getEmployeeByGender(String gender) {
        return employeeDao.getEmployeeByGender(gender);
    }

}
